#include "main.h"

t_config *new_config() {
    t_config *config = malloc(sizeof(t_config));

    mx_memset(config, 0, sizeof(t_config));
    if (isatty(1)) {
        config->format = HAS_FLAG_BIG_C;
    }
    return config;
}

t_config *parse_args(int argc, char *argv[]) {
    t_config *config = new_config();

    for (int i = 1; i < argc; i++) {
        if (argv[i][0] != '-') {
            break;
        }
        for (char *flag = argv[i] + 1; *flag != '\0'; flag++) {
            switch (*flag) {
            case 'R':
                config->has_flag_big_r = true;
                break;
            case 'G':
                config->has_flag_big_g = true;
                break;
            case 'F':
                config->has_flag_big_f = true;
                config->has_flag_p = false;
                break;
            case 'p':
                config->has_flag_p = true;
                config->has_flag_big_f = false;
                break;
            case 'r':
                config->has_flag_r = true;
                break;
            case 'h':
                config->has_flag_h = true;
                break;
            case 'e':
                config->has_flag_e = true;
                break;
            case 'T':
                config->has_flag_big_t = true;
                break;
            case '@':
                config->has_flag_at = true;
                break;
            case 'g':
                config->has_flag_g = true;
                break;
            case 'o':
                config->has_flag_o = true;
                break;
            case 'q':
                config->has_flag_q = true;
                break;
            case 'H':
                config->has_flag_big_h = true;
                break;
            case '1':
                config->format = HAS_FLAG_1;
                break;
            case 'C':
                config->format = HAS_FLAG_BIG_C;
                break;
            case 'm':
                config->format = HAS_FLAG_M;
                break;
            case 'l':
                config->format = HAS_FLAG_L;
                break;
            case 'c':
                config->time_type = HAS_FLAG_C;
                break;
            case 'u':
                config->time_type = HAS_FLAG_U;
                break;
            case 'U':
                config->time_type = HAS_FLAG_BIG_U;
                break;
            case 't':
                config->sort_type = HAS_FLAG_T;
                break;
            case 'S':
                config->sort_type = HAS_FLAG_BIG_S;
                break;
            case 'f':
                config->sort_type = HAS_FLAG_F;
                config->ignore_type = HAS_FLAG_A;
                break;
            case 'A':
                config->ignore_type = HAS_FLAG_BIG_A;
                break;
            case 'a':
                config->ignore_type = HAS_FLAG_A;
                break;
            default:
                mx_printerr("uls: illegal option -- ");
                write(2, flag, 1);
                write(2, "\n", 1);
                mx_printerr("usage: uls [-@ACFGHRSTUacefghlmopqrtu1] [file ...]\n");
                exit(1);
            }
        }
    }

    if (!isatty(1)) {
        config->has_flag_big_g = false;
    } 
    else {
        config->has_flag_q = true;
    }

    if (!config->has_flag_big_h) {
        config->has_flag_big_h =
            config->format != HAS_FLAG_L && !config->has_flag_big_g && !config->has_flag_big_f;
    }

    if (config->sort_type == HAS_FLAG_F) {
        config->ignore_type = HAS_FLAG_A;
    }

    return config;
}

static char *get_user_name(uid_t uid) {
    struct passwd *passwd = getpwuid(uid);
    if (passwd == NULL) {
        return mx_ltoa(uid);
    }
    return mx_strdup(passwd->pw_name);
}

static char *get_group_name(gid_t gid) {
    struct group *group = getgrgid(gid);
    if (group == NULL) {
        return mx_ltoa(gid);
    }
    return mx_strdup(group->gr_name);
}

static struct timespec get_timespec(struct stat *stat, t_time time_type) {
    switch (time_type) {
    case IS_DEFAULT_TIME:
        return stat->st_mtimespec;
    case HAS_FLAG_C:
        return stat->st_ctimespec;
    case HAS_FLAG_U:
        return stat->st_atimespec;
    case HAS_FLAG_BIG_U:
        return stat->st_birthtimespec;
    }
}

static char **get_xattr_keys(const char *filename) {
    char buffer[1024] = {'\0'};
    ssize_t count = listxattr(filename, buffer, sizeof(buffer), XATTR_NOFOLLOW);

    for (int i = 0; i < count - 1; i++) {
        if (buffer[i] == '\0') {
            buffer[i] = ':';
        }
    }

    if (count > 0) {
        return mx_strsplit(buffer, ':');
    }
    return NULL;
}

t_fileinfo *get_fileinfo(const char *dir, const char *name, t_config *config) {
    t_fileinfo *fileinfo = malloc(sizeof(t_fileinfo));

    fileinfo->path = mx_strjoin_delim(dir, name, '/');
    fileinfo->name = mx_strdup(name);
    fileinfo->user = NULL;
    fileinfo->link = NULL;
    fileinfo->group = NULL;
    fileinfo->xattr_keys = NULL;
    fileinfo->acl = NULL;

    int err;
    if (dir == NULL && config->has_flag_big_h) {
        err = stat(fileinfo->path, &fileinfo->stat);
    } else {
        err = lstat(fileinfo->path, &fileinfo->stat);
    }

    if (err != 0) {
        free_fileinfo(fileinfo);
        return NULL;
    }

    if (config->format == HAS_FLAG_L) {
        fileinfo->user = get_user_name(fileinfo->stat.st_uid);
        fileinfo->group = get_group_name(fileinfo->stat.st_gid);
        if (S_ISLNK(fileinfo->stat.st_mode)) {
            fileinfo->link = malloc(PATH_MAX);
            ssize_t size = readlink(fileinfo->path, fileinfo->link, PATH_MAX);
            fileinfo->link[size] = '\0';
        } else {
            fileinfo->link = NULL;
            fileinfo->acl = acl_get_file(fileinfo->path, ACL_TYPE_EXTENDED);
        }
        fileinfo->xattr_keys = get_xattr_keys(fileinfo->path);
    }
    fileinfo->timespec = get_timespec(&fileinfo->stat, config->time_type);

    return fileinfo;
}

bool is_ignored(const char *name, t_ignore ignore_type) {
    if (ignore_type == IS_DEFAULT_IGNORE && name[0] == '.') {
        return true;
    }
    if (ignore_type == HAS_FLAG_BIG_A && (mx_strcmp(name, ".") == 0 || mx_strcmp(name, "..") == 0)) {
        return true;
    }
    return false;
}

bool get_dir_entries(t_list **entries, const char *name, t_config *config) {
    DIR *dir = opendir(name);
    struct dirent *entry = NULL;

    if (dir == NULL) {
        return false;
    }

    while ((entry = readdir(dir)) != NULL) {
        if (!is_ignored(entry->d_name, config->ignore_type)) {
            mx_push_back(entries, get_fileinfo(name, entry->d_name, config));
        }
    }

    closedir(dir);
    return true;
}

void free_fileinfo(t_fileinfo *fileinfo) {
    free(fileinfo->path);
    free(fileinfo->name);
    mx_strdel(&fileinfo->user);
    mx_strdel(&fileinfo->link);
    mx_strdel(&fileinfo->group);
    mx_del_strarr(&fileinfo->xattr_keys);
    acl_free(fileinfo->acl);
    free(fileinfo);
}

blkcnt_t count_blocks(t_list *files) {
    t_list *current = files;
    blkcnt_t blocks = 0;

    while (current != NULL) {
        t_fileinfo *fileinfo = current->data;

        blocks += fileinfo->stat.st_blocks;
        current = current->next;
    }

    return blocks;
}

static bool compare_strings(void *data1, void *data2) {
    return mx_strcmp(data1, data2) > 0;
}

void sort_filenames(t_list *filenames, t_sort sort_type) {
    if (sort_type != HAS_FLAG_F) {
        mx_sort_list(filenames, compare_strings, false);
    }
}

static bool compare_by_name(void *data1, void *data2) {
    t_fileinfo *fileinfo1 = data1;
    t_fileinfo *fileinfo2 = data2;

    return mx_strcmp(fileinfo1->name, fileinfo2->name) > 0;
}

static bool compare_by_time(void *data1, void *data2) {
    t_fileinfo *fileinfo1 = data1;
    t_fileinfo *fileinfo2 = data2;
    
    if (fileinfo1->timespec.tv_sec == fileinfo2->timespec.tv_sec) {
        if (fileinfo1->timespec.tv_nsec == fileinfo2->timespec.tv_nsec) {
            return mx_strcmp(fileinfo1->name, fileinfo2->name) > 0;
        }
        return fileinfo1->timespec.tv_nsec < fileinfo2->timespec.tv_nsec;
    }
    return fileinfo1->timespec.tv_sec < fileinfo2->timespec.tv_sec;
}

static bool compare_by_size(void *data1, void *data2) {
    t_fileinfo *fileinfo1 = data1;
    t_fileinfo *fileinfo2 = data2;

    if (fileinfo1->stat.st_size == fileinfo2->stat.st_size) {
        return mx_strcmp(fileinfo1->name, fileinfo2->name) > 0;
    }

    return fileinfo1->stat.st_size < fileinfo2->stat.st_size;
}

void sort_fileinfos(t_list *fileinfos, t_sort sort_type, bool reverse) {
    switch (sort_type) {
    case IS_DEFAULT_SORT:
        mx_sort_list(fileinfos, compare_by_name, reverse);
        break;
    case HAS_FLAG_T:
        mx_sort_list(fileinfos, compare_by_time, reverse);
        break;
    case HAS_FLAG_BIG_S:
        mx_sort_list(fileinfos, compare_by_size, reverse);
        break;
    default:
        break;
    }
}

