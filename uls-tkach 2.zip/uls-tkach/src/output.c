#include "main.h"

static void print_color(mode_t mode) {
    switch (mode & S_IFMT) {
    case S_IFBLK:
        mx_printstr("\033[34;46m");
        break;
    case S_IFCHR:
        mx_printstr("\033[34;43m");
        break;
    case S_IFDIR:
        if (mode & S_IWOTH) {
            if (mode & S_ISTXT) {
                mx_printstr("\033[30;42m");
            } else {
                mx_printstr("\033[30;43m");
            }
        } 
        else {
            mx_printstr("\033[34m");
        }
        break;
    case S_IFIFO:
        mx_printstr("\033[33m");
        break;
    case S_IFLNK:
        mx_printstr("\033[35m");
        break;
    case S_IFSOCK:
        mx_printstr("\033[32m");
        break;
    default:
        if (mode & (S_IXUSR | S_IXGRP | S_IXOTH)) {
            if (mode & S_ISUID) {
                mx_printstr("\033[30;41m");
            } 
            else if (mode & S_ISGID) {
                mx_printstr("\033[30;46m");
            } 
            else {
                mx_printstr("\033[31m");
            }
        }
        break;
    }
}

static int print_classifier(mode_t mode, bool slash_only) {
    char classifier = '\0';

    switch (mode & S_IFMT) {
    case S_IFDIR:
        classifier = '/';
        break;
    case S_IFIFO:
        classifier = '|';
        break;
    case S_IFLNK:
        classifier = '@';
        break;
    case S_IFSOCK:
        classifier = '=';
        break;
    case S_IFREG:
        if (mode & (S_IXUSR | S_IXGRP | S_IXOTH)) {
            classifier = '*';
        }
        break;
    }

    if (classifier != '\0') {
        if (slash_only && classifier != '/') {
            return 0;
        }
        mx_printchar(classifier);
        return 1;
    }
    return 0;
}

static char *substitute_non_printable(const char *name) {
    char *tmp = mx_strdup(name);

    for (int i = 0; tmp[i] != '\0'; i++) {
        if (tmp[i] >= 0 && tmp[i] <= 31) {
            tmp[i] = '?';
        }
    }

    return tmp;
}

static void print_name(const char *name, bool has_flag_q) {
    if (has_flag_q) {
        char *str = substitute_non_printable(name);

        mx_printstr(str);
        free(str);
    } 
    else {
        mx_printstr(name);
    }
}

int print_fileinfo(t_fileinfo *fileinfo, t_config *config) {
    if (config->has_flag_big_g) {
        print_color(fileinfo->stat.st_mode);
    }
    print_name(fileinfo->name, config->has_flag_q);
    if (config->has_flag_big_g) {
        mx_printstr("\033[0m");
    }

    int count = mx_strlen(fileinfo->name);

    if (config->has_flag_big_f || config->has_flag_p) {
        count += print_classifier(fileinfo->stat.st_mode, config->has_flag_p);
    }

    return count;
}

void print_singlecolumn(t_list *fileinfos, t_config *config) {
    while (fileinfos != NULL) {
        print_fileinfo(fileinfos->data, config);
        mx_printchar('\n');
        fileinfos = fileinfos->next;
    }
}

void print_stream(t_list *fileinfos, t_config *config) {
    while (fileinfos != NULL) {
        print_fileinfo(fileinfos->data, config);
        if (fileinfos->next != NULL) {
            mx_printstr(", ");
        }
        fileinfos = fileinfos->next;
    }
    mx_printchar('\n');
}

void print_fileinfos(t_list *fileinfos, t_config *config) {
    switch (config->format) {
    case HAS_FLAG_1:
        print_singlecolumn(fileinfos, config);
        break;
    case HAS_FLAG_BIG_C:
        print_multicolumn(fileinfos, config);
        break;
    case HAS_FLAG_M:
        print_stream(fileinfos, config);
        break;
    case HAS_FLAG_L:
        print_long(fileinfos, config);
        break;
    default:
        break;
    }
}
