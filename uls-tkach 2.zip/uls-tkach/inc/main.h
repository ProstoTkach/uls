#pragma once
#include "libmx.h"

#include <stdbool.h>
#include <dirent.h>
#include <grp.h>
#include <pwd.h>
#include <sys/acl.h>
#include <sys/stat.h>
#include <sys/syslimits.h>
#include <sys/types.h>
#include <sys/xattr.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <time.h>

typedef enum {
    HAS_FLAG_1,
    HAS_FLAG_BIG_C,
    HAS_FLAG_M,
    HAS_FLAG_L,
} t_format;

typedef enum {
    IS_DEFAULT_TIME,
    HAS_FLAG_C,
    HAS_FLAG_U,
    HAS_FLAG_BIG_U,
} t_time;

typedef enum {
    IS_DEFAULT_SORT,
    HAS_FLAG_T,
    HAS_FLAG_BIG_S,
    HAS_FLAG_F,
} t_sort;

typedef enum {
    IS_DEFAULT_IGNORE,
    HAS_FLAG_BIG_A,
    HAS_FLAG_A,
} t_ignore;

typedef struct {
    t_format format;
    t_time time_type;
    t_sort sort_type;
    t_ignore ignore_type;
    bool has_flag_big_r;
    bool has_flag_big_g;
    bool has_flag_big_f;
    bool has_flag_p;
    bool has_flag_r;
    bool has_flag_h;
    bool has_flag_e;
    bool has_flag_big_t;
    bool has_flag_at;
    bool has_flag_g;
    bool has_flag_o;
    bool has_flag_q;
    bool has_flag_big_h;
} t_config;

typedef struct {
    char *path;
    char *name;
    char *user;
    char *link;
    char *group;
    char **xattr_keys;
    acl_t acl;
    struct stat stat;
    struct timespec timespec;
} t_fileinfo;

typedef struct {
    int links;
    int user;
    int group;
    int size;
} t_width;

t_config *parse_args(int argc, char *argv[]);

t_fileinfo *get_fileinfo(const char *dir, const char *name, t_config *config);
bool get_dir_entries(t_list **entries, const char *name, t_config *config);
bool is_ignored(const char *name, t_ignore ignore_type);
void free_fileinfo(t_fileinfo *fileinfo);
blkcnt_t count_blocks(t_list *files);

int print_fileinfo(t_fileinfo *fileinfo, t_config *config);
void print_singlecolumn(t_list *fileinfos, t_config *config);
void print_multicolumn(t_list *fileinfos, t_config *config);
void print_long(t_list *fileinfos, t_config *config);
void print_fileinfos(t_list *fileinfos, t_config *config);

void sort_filenames(t_list *filenames, t_sort sort_type);
void sort_fileinfos(t_list *fileinfos, t_sort sort_type, bool reverse);
